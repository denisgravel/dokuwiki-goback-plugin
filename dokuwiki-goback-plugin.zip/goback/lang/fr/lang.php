<?php

$lang['goback_button'] = 'Page précédente';
