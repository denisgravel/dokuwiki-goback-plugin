<?php

$lang['goback_button'] = "Previous page";
